import CoreImage
import Darwin
import Foundation
import VideoToolbox

/// 张雪 500RR 仪表（5 寸 TFT）的输出规格。
///
/// 公开可查的参数只有拓扑：仪表热点地址 192.168.43.1，视频通道 1111，消息通道 11113，
/// 由仪表返回画面参数后手机发送 H.264。真实握手报文尚未抓到，因此这里把规格做成可切换，
/// 默认按 800×480 起播；收到仪表参数后自动改用仪表上报的尺寸。
struct Zx500rrProfile: Equatable {
    let width: Int
    let height: Int
    let fps: Int
    let bitrate: Int
    let label: String

    static let fiveInch = Zx500rrProfile(width: 800, height: 480, fps: 30, bitrate: 4_000_000, label: "张雪 500RR 800×480")
    static let fiveInchHD = Zx500rrProfile(width: 1280, height: 720, fps: 30, bitrate: 6_000_000, label: "张雪 500RR 1280×720")
    static let all: [Zx500rrProfile] = [.fiveInch, .fiveInchHD]

    var encodeWidth: Int { width - width % 2 }
    var encodeHeight: Int { height % 2 == 0 ? height : height + 1 }
    var title: String { "\(width)×\(height)" }
    var choiceTitle: String { title }
}

/// 张雪 500RR 会话：手机作为客户端，主动连仪表热点上的 1111（视频）与 11113（消息）。
/// 视频通道上仪表可能先下发画面参数，读到就采用；消息通道只读并记录，用于后续补协议。
final class Zx500rrConnection: @unchecked Sendable {
    struct MediaSize: Equatable {
        let width: Int
        let height: Int
        let fps: Int
    }

    enum Port {
        static let video: UInt16 = 1111
        static let message: UInt16 = 11113
    }

    private let localIP: String
    private let targetIP: String
    private let dashboard: String
    private let log: (String) -> Void

    private let condition = NSCondition()
    private var video: ZxSocket?
    private var message: ZxSocket?
    private var closed = false
    private var failure: Error?
    private var negotiated = MediaSize(width: 800, height: 480, fps: 30)
    private var framesSent = 0

    init(localIP: String, targetIP: String, dashboard: String, log: @escaping (String) -> Void) {
        self.localIP = localIP
        self.targetIP = targetIP
        self.dashboard = dashboard
        self.log = log
    }

    /// 当前使用的画面规格（仪表上报后会被替换）。
    var mediaSize: MediaSize {
        condition.lock(); defer { condition.unlock() }
        return negotiated
    }

    /// 仪表热点通常把自己放在网关 .1；本机 IP 的 .1 就是 192.168.43.1。
    static func gateway(for localIP: String) -> String? {
        var parts = localIP.split(separator: ".").map(String.init)
        guard parts.count == 4, Int(parts[3]) != nil else { return nil }
        parts[3] = "1"
        return parts.joined(separator: ".")
    }

    func start() throws {
        let socket = try ZxSocket()
        try socket.connect(localIP: localIP, remoteIP: targetIP, port: Port.video, timeout: 3)
        condition.lock(); video = socket; condition.unlock()
        log("\(dashboard) 已连接视频通道 \(targetIP):\(Port.video)")

        if let packet = try? socket.readAvailable(max: 4096, timeout: 2.0), !packet.isEmpty {
            log("\(dashboard) 视频通道首包 \(packet.count) 字节：\(Self.preview(packet))")
            if let size = Self.parseMediaSize(packet) {
                condition.lock(); negotiated = size; condition.unlock()
                log("\(dashboard) 仪表上报画面 \(size.width)×\(size.height)@\(size.fps)")
            } else {
                log("\(dashboard) 首包未解析出画面参数，继续按默认规格发送")
            }
        } else {
            let current = mediaSize
            log("\(dashboard) 2 秒内未收到画面参数，按默认 \(current.width)×\(current.height)@\(current.fps) 起播")
        }

        do {
            let channel = try ZxSocket()
            try channel.connect(localIP: localIP, remoteIP: targetIP, port: Port.message, timeout: 3)
            condition.lock(); message = channel; condition.unlock()
            log("\(dashboard) 已连接消息通道 \(targetIP):\(Port.message)")
            readMessages(channel)
        } catch {
            log("\(dashboard) 消息通道连接失败：\(error.localizedDescription)；仅走视频通道")
        }
    }

    func checkHealth() throws {
        condition.lock(); let stopped = closed; let stored = failure; condition.unlock()
        if stopped { throw TailingError.closed }
        if let stored { throw stored }
    }

    func send(_ frame: Data) throws {
        condition.lock(); let stopped = closed; let socket = video; condition.unlock()
        guard !stopped, let socket else { throw TailingError.closed }
        try socket.write(frame)
        condition.lock(); framesSent += 1; let first = framesSent == 1; condition.unlock()
        if first { log("\(dashboard) 首帧已发送（\(frame.count) 字节 Annex-B）") }
    }

    func close() {
        condition.lock()
        closed = true
        let videoSocket = video
        let messageSocket = message
        video = nil
        message = nil
        condition.broadcast()
        condition.unlock()
        videoSocket?.close()
        messageSocket?.close()
    }

    private func fail(_ error: Error) {
        condition.lock()
        if failure == nil { failure = error }
        condition.broadcast()
        condition.unlock()
    }

    private func readMessages(_ socket: ZxSocket) {
        DispatchQueue.global(qos: .userInitiated).async { [self] in
            while true {
                condition.lock(); let stopped = closed; condition.unlock()
                if stopped { return }
                do {
                    let packet = try socket.readAvailable(max: 4096, timeout: 1.0)
                    guard !packet.isEmpty else { continue }
                    log("\(dashboard) 消息通道收到 \(packet.count) 字节：\(Self.preview(packet))")
                    if let size = Self.parseMediaSize(packet) {
                        condition.lock(); negotiated = size; condition.unlock()
                        log("\(dashboard) 消息中的画面参数：\(size.width)×\(size.height)@\(size.fps)")
                    }
                } catch let error as TailingError {
                    if case .timeout = error { continue }
                    if case .closed = error { return }
                    fail(error)
                    log("\(dashboard) 消息通道结束：\(error.localizedDescription)")
                    return
                } catch {
                    fail(error)
                    log("\(dashboard) 消息通道结束：\(error.localizedDescription)")
                    return
                }
            }
        }
    }

    /// 仪表参数可能是 JSON，也可能是“宽/高/帧率”的小端 16 位；两种都尝试。
    static func parseMediaSize(_ data: Data) -> MediaSize? {
        if let object = try? JSONSerialization.jsonObject(with: data),
           let dictionary = object as? [String: Any],
           let size = mediaSize(from: dictionary, depth: 0) {
            return size
        }
        if data.count >= 6 {
            let width = Int(data.uint16LE(0))
            let height = Int(data.uint16LE(2))
            let fps = Int(data.uint16LE(4))
            if (320...1920).contains(width), (240...1080).contains(height), (5...60).contains(fps) {
                return MediaSize(width: width, height: height, fps: fps)
            }
        }
        return nil
    }

    private static func mediaSize(from dictionary: [String: Any], depth: Int) -> MediaSize? {
        guard depth < 3 else { return nil }
        for key in ["data", "params", "media", "screen", "resolution"] {
            if let nested = dictionary[key] as? [String: Any],
               let size = mediaSize(from: nested, depth: depth + 1) {
                return size
            }
        }
        let width = number(dictionary["width"]) ?? number(dictionary["w"]) ?? number(dictionary["Width"])
        let height = number(dictionary["height"]) ?? number(dictionary["h"]) ?? number(dictionary["Height"])
        guard let width, let height, (320...1920).contains(width), (240...1080).contains(height) else { return nil }
        let fps = number(dictionary["fps"]) ?? number(dictionary["frameRate"]) ?? 30
        return MediaSize(width: width, height: height, fps: min(max(fps, 5), 60))
    }

    private static func number(_ value: Any?) -> Int? {
        if let value = value as? Int { return value }
        if let value = value as? Double { return Int(value) }
        if let value = value as? String { return Int(value) }
        return nil
    }

    /// 抓包时最有用的一行：前若干字节的十六进制 + 可见文本。
    static func preview(_ data: Data) -> String {
        let head = data.prefix(24).map { String(format: "%02X", $0) }.joined(separator: " ")
        let text = (String(data: data.prefix(96), encoding: .utf8) ?? "")
            .replacingOccurrences(of: "\r", with: " ")
            .replacingOccurrences(of: "\n", with: " ")
        return text.isEmpty ? head : "\(head)｜\(text)"
    }
}

/// 张雪 500RR 投屏输出：把 CarPlay 的 H.264 解回像素，缩放成仪表尺寸重新编码，
/// 再按目标帧率把 Annex-B 帧写到 1111 视频通道。消息通道内容只做记录，等待实机抓包补全。
final class Zx500rrOutput {
    private let queue: DispatchQueue
    private var session: Session?

    init(name: String = "zx500rr") {
        queue = DispatchQueue(label: "CarWithin.\(name)", qos: .userInitiated)
    }

    deinit { stop() }

    func start(localAddress: String, targetAddress: String, profile: Zx500rrProfile,
               onState: @escaping (String) -> Void, onLog: @escaping (String) -> Void,
               requestKeyframe: @escaping () -> Void) {
        stop()
        let next = Session(queue: queue, localAddress: localAddress, targetAddress: targetAddress,
                           profile: profile, onState: onState, onLog: onLog, requestKeyframe: requestKeyframe)
        session = next
        next.start()
    }

    func append(_ data: Data, codec: VideoCodec, keyframe: Bool) {
        guard codec == .h264 else { return }
        session?.append(data, keyframe: keyframe)
    }

    func stop() {
        guard let previous = session else { return }
        session = nil
        previous.cancel()
        queue.async { previous.close() }
    }

    private final class Session: @unchecked Sendable {
        let queue: DispatchQueue
        let profile: Zx500rrProfile
        let onState: (String) -> Void
        let onLog: (String) -> Void
        let requestKeyframe: () -> Void
        private let lock = NSLock()
        private var cancelled = false
        private var acceptingFrames = true
        private var queued = 0
        private var skipping = false
        private var decoded: CVPixelBuffer?
        private var decodeError: Error?
        private var encoded: Result<H264EncodedFrame, Error>?

        private var encodeWidth: Int
        private var encodeHeight: Int
        private var frameRate: Int
        private let connection: Zx500rrConnection
        private var decoder: TailingH264Decoder?
        private var encoder: H264Encoder?
        private var parameters = VideoParameterSets(codec: .h264)
        private var waitingForIDR = true
        private var latest: CVPixelBuffer?
        private lazy var compositor = CIContext(options: [.useSoftwareRenderer: true, .cacheIntermediates: false])
        private var lastKeyframe = -Double.infinity
        private var lastCodecFailure = -Double.infinity
        private var status = ""

        init(queue: DispatchQueue, localAddress: String, targetAddress: String, profile: Zx500rrProfile,
             onState: @escaping (String) -> Void, onLog: @escaping (String) -> Void,
             requestKeyframe: @escaping () -> Void) {
            self.queue = queue
            self.profile = profile
            self.encodeWidth = profile.encodeWidth
            self.encodeHeight = profile.encodeHeight
            self.frameRate = profile.fps
            self.connection = Zx500rrConnection(localIP: localAddress, targetIP: targetAddress,
                                                dashboard: profile.label, log: onLog)
            self.onState = onState
            self.onLog = onLog
            self.requestKeyframe = requestKeyframe
        }

        func start() {
            report("正在连接\(profile.label)仪表…")
            DispatchQueue.global(qos: .userInitiated).async { [self] in
                do {
                    try connection.start()
                    guard active else { return }
                    let size = connection.mediaSize
                    encodeWidth = size.width - size.width % 2
                    encodeHeight = size.height % 2 == 0 ? size.height : size.height + 1
                    frameRate = size.fps
                    report("仪表已连接，等待 CarPlay 画面…")
                    var first = true
                    var nextFrame = ProcessInfo.processInfo.systemUptime
                    while active {
                        try connection.checkHealth()
                        let ready = queue.sync { latest != nil }
                        if !ready { Thread.sleep(forTimeInterval: 0.05); continue }
                        let now = ProcessInfo.processInfo.systemUptime
                        let remaining = nextFrame - now
                        if remaining > 0 { Thread.sleep(forTimeInterval: min(remaining, 0.04)); continue }
                        nextFrame = now + 1.0 / Double(max(frameRate, 5))
                        let result = queue.sync { () -> H264EncodedFrame? in
                            guard active, let image = latest else { return nil }
                            return encode(image, at: ProcessInfo.processInfo.systemUptime, forceKeyframe: first)
                        }
                        guard let result else {
                            // 仪表已经在收流：等一帧可编码画面，用关键帧补上。
                            var recovered: H264EncodedFrame?
                            for _ in 0..<20 where active && recovered == nil {
                                Thread.sleep(forTimeInterval: 0.05)
                                recovered = queue.sync { () -> H264EncodedFrame? in
                                    guard let image = latest else { return nil }
                                    return encode(image, at: ProcessInfo.processInfo.systemUptime, forceKeyframe: true)
                                }
                            }
                            guard let recovered else { continue }
                            try connection.send(recovered.data)
                            first = false
                            report("正在投屏 · \(profile.title) · H.264")
                            continue
                        }
                        try connection.send(result.data)
                        first = false
                        report("正在投屏 · \(profile.title) · H.264")
                    }
                } catch {
                    if active {
                        onLog("\(profile.label)输出失败：\(error.localizedDescription)")
                        report("\(profile.label)连接失败：\(error.localizedDescription)")
                    }
                }
                connection.close()
                queue.async { [self] in close() }
            }
        }

        private var active: Bool { lock.withLock { !cancelled } }

        func cancel() { lock.withLock { cancelled = true }; connection.close() }

        func append(_ data: Data, keyframe: Bool) {
            let (accepted, needsKeyframe) = lock.withLock {
                guard !cancelled, acceptingFrames else { return (false, false) }
                if queued >= 6 {
                    let request = !skipping
                    skipping = true
                    return (false, request)
                }
                guard !skipping || keyframe else { return (false, false) }
                skipping = false
                queued += 1
                return (true, false)
            }
            if needsKeyframe { requestKeyframe() }
            guard accepted else { return }
            queue.async { [self] in
                defer { lock.withLock { queued -= 1 } }
                guard lock.withLock({ !cancelled && acceptingFrames }) else { return }
                decode(data, keyframe: keyframe)
            }
        }

        private func decode(_ data: Data, keyframe: Bool) {
            do {
                var picture: [Data] = []
                for unit in try AnnexB.units(in: data) {
                    if VideoCodec.h264.parameterSet(unit) != nil {
                        if parameters.absorb(unit) { waitingForIDR = true }
                    } else { picture.append(unit) }
                }
                if waitingForIDR {
                    guard parameters.isComplete, keyframe, !picture.isEmpty else { return }
                    guard ProcessInfo.processInfo.systemUptime - lastCodecFailure >= 0.5 else {
                        requestKeyframe()
                        return
                    }
                    decoder?.invalidate()
                    decoder = try TailingH264Decoder(configuration: parameters.decoderConfigurationRecord(),
                        output: { [weak self] image in
                            guard let self else { return }
                            self.lock.withLock { self.decoded = image }
                        }, failure: { [weak self] error in
                            guard let self else { return }
                            self.lock.withLock { self.decodeError = error }
                        })
                    waitingForIDR = false
                }
                guard let decoder, !picture.isEmpty else { return }
                try decoder.decode(AnnexB.lengthPrefixed(picture),
                    presentationTimeMicroseconds: Int64(ProcessInfo.processInfo.systemUptime * 1_000_000), isKeyframe: keyframe)
                decoder.waitForFrames()
                let (image, error) = lock.withLock {
                    defer { decoded = nil; decodeError = nil }
                    return (decoded, decodeError)
                }
                if let error { throw error }
                if let image { latest = image }
            } catch {
                decoder?.invalidate()
                decoder = nil
                lock.withLock { decoded = nil; decodeError = nil }
                waitingForIDR = true
                logCodecFailure("解码", error)
                requestKeyframe()
            }
        }

        private func encode(_ image: CVPixelBuffer, at now: Double, forceKeyframe: Bool) -> H264EncodedFrame? {
            do {
                if encoder == nil {
                    guard now - lastCodecFailure >= 0.5 else { return nil }
                    encoder = try H264Encoder(width: encodeWidth, height: encodeHeight,
                                              fps: frameRate, bitrate: profile.bitrate) { [weak self] result in
                        guard let self else { return }
                        self.lock.withLock { self.encoded = result }
                    }
                    lastKeyframe = -.infinity
                }
                guard let encoder else { return nil }
                let stamp = CMTime(seconds: now, preferredTimescale: 1_000_000)
                try encoder.encode(try fittedImage(image), presentationTime: stamp,
                                   forceKeyframe: forceKeyframe || lastKeyframe == -.infinity)
                encoder.complete()
                let result = lock.withLock {
                    defer { encoded = nil }
                    return encoded
                }
                let frame = try result?.get()
                if frame?.isKeyframe == true { lastKeyframe = now }
                return frame
            } catch H264EncoderError.frameDropped {
                return nil
            } catch {
                encoder?.invalidate()
                encoder = nil
                lastKeyframe = -.infinity
                lock.withLock { encoded = nil }
                logCodecFailure("编码", error)
                return nil
            }
        }

        private func fittedImage(_ image: CVPixelBuffer) throws -> CVPixelBuffer {
            let width = encodeWidth, height = encodeHeight
            if CVPixelBufferGetWidth(image) == width, CVPixelBufferGetHeight(image) == height { return image }
            var buffer: CVPixelBuffer?
            let status = CVPixelBufferCreate(kCFAllocatorDefault, width, height, kCVPixelFormatType_32BGRA,
                                             [kCVPixelBufferIOSurfacePropertiesKey: [:]] as CFDictionary, &buffer)
            guard status == kCVReturnSuccess, let buffer else {
                throw ConfigurationError("无法分配\(profile.label)缩放画面（\(status)）")
            }
            let source = CIImage(cvPixelBuffer: image)
            let scale = min(CGFloat(width) / source.extent.width, CGFloat(height) / source.extent.height)
            let scaled = source.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
            let positioned = scaled.transformed(by: CGAffineTransform(
                translationX: (CGFloat(width) - scaled.extent.width) / 2,
                y: (CGFloat(height) - scaled.extent.height) / 2))
            let bounds = CGRect(x: 0, y: 0, width: width, height: height)
            compositor.render(positioned.composited(over: CIImage(color: .black)).cropped(to: bounds),
                              to: buffer, bounds: bounds, colorSpace: CGColorSpaceCreateDeviceRGB())
            return buffer
        }

        private func logCodecFailure(_ stage: String, _ error: Error) {
            let now = ProcessInfo.processInfo.systemUptime
            if now - lastCodecFailure > 4 { onLog("\(profile.label)\(stage)恢复：\(error.localizedDescription)") }
            lastCodecFailure = now
        }

        private func report(_ message: String) {
            guard active, message != status else { return }
            status = message
            DispatchQueue.main.async { [weak self] in
                guard let self, self.active else { return }
                self.onState(message)
            }
        }

        func close() {
            lock.withLock { acceptingFrames = false }
            connection.close()
            decoder?.invalidate()
            decoder = nil
            encoder?.invalidate()
            encoder = nil
            latest = nil
        }
    }
}

/// 极简非阻塞 TCP 客户端。这里需要“读到多少算多少”，所以没有复用 TailingSocket 的定长读取。
private final class ZxSocket: @unchecked Sendable {
    private let lock = NSLock()
    private let writer = NSLock()
    private var descriptor: Int32 = -1

    init() throws {
        let socket = Darwin.socket(AF_INET, SOCK_STREAM, 0)
        guard socket >= 0 else { throw TailingError.system("创建 TCP", errno) }
        descriptor = socket
        let flags = fcntl(socket, F_GETFL, 0)
        guard flags >= 0, fcntl(socket, F_SETFL, flags | O_NONBLOCK) == 0 else {
            close()
            throw TailingError.system("设置 TCP 非阻塞", errno)
        }
        var enabled: Int32 = 1
        _ = setsockopt(socket, SOL_SOCKET, SO_NOSIGPIPE, &enabled, socklen_t(MemoryLayout<Int32>.size))
        _ = setsockopt(socket, IPPROTO_TCP, TCP_NODELAY, &enabled, socklen_t(MemoryLayout<Int32>.size))
    }

    deinit { close() }

    func connect(localIP: String, remoteIP: String, port: UInt16, timeout: TimeInterval) throws {
        var local = try Self.address(localIP, 0)
        let bound = withUnsafePointer(to: &local) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                Darwin.bind(descriptor, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
            }
        }
        guard bound == 0 else { throw TailingError.system("绑定本机地址", errno) }
        var remote = try Self.address(remoteIP, port)
        let result = withUnsafePointer(to: &remote) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                Darwin.connect(descriptor, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
            }
        }
        if result != 0 {
            guard errno == EINPROGRESS else { throw TailingError.system("连接 TCP\(port)", errno) }
            try wait(events: Int16(POLLOUT), deadline: Self.now + timeout, operation: "连接 TCP\(port)")
            var error: Int32 = 0
            var size = socklen_t(MemoryLayout<Int32>.size)
            guard getsockopt(descriptor, SOL_SOCKET, SO_ERROR, &error, &size) == 0, error == 0 else {
                throw TailingError.system("连接 TCP\(port)", error)
            }
        }
    }

    func write(_ data: Data) throws {
        writer.lock()
        defer { writer.unlock() }
        let deadline = Self.now + 5
        var offset = 0
        try data.withUnsafeBytes { raw in
            while offset < data.count {
                try wait(events: Int16(POLLOUT), deadline: deadline, operation: "发送视频数据")
                let sent = Darwin.send(descriptor, raw.baseAddress!.advanced(by: offset), data.count - offset, 0)
                if sent > 0 { offset += sent }
                else if sent == 0 { throw TailingError.closed }
                else if errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR {
                    throw TailingError.system("发送视频数据", errno)
                }
            }
        }
    }

    func readAvailable(max: Int, timeout: TimeInterval) throws -> Data {
        try wait(events: Int16(POLLIN), deadline: Self.now + timeout, operation: "接收仪表数据")
        var buffer = [UInt8](repeating: 0, count: max)
        let received = buffer.withUnsafeMutableBytes { Darwin.recv(descriptor, $0.baseAddress, max, 0) }
        if received > 0 { return Data(buffer[0..<received]) }
        if received == 0 { throw TailingError.closed }
        if errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR { return Data() }
        throw TailingError.system("接收仪表数据", errno)
    }

    func close() {
        lock.lock()
        let socket = descriptor
        descriptor = -1
        lock.unlock()
        guard socket >= 0 else { return }
        _ = Darwin.shutdown(socket, SHUT_RDWR)
        Darwin.close(socket)
    }

    private func wait(events: Int16, deadline: TimeInterval, operation: String) throws {
        while true {
            lock.lock()
            let socket = descriptor
            lock.unlock()
            guard socket >= 0 else { throw TailingError.closed }
            let remaining = deadline - Self.now
            guard remaining > 0 else { throw TailingError.timeout(operation) }
            var item = pollfd(fd: socket, events: events, revents: 0)
            let result = Darwin.poll(&item, 1, Int32(max(1.0, min(50.0, remaining * 1_000))))
            if result > 0 {
                if item.revents & Int16(POLLNVAL) != 0 { throw TailingError.closed }
                return
            }
            if result < 0 && errno != EINTR { throw TailingError.system(operation, errno) }
        }
    }

    private static var now: TimeInterval { ProcessInfo.processInfo.systemUptime }

    private static func address(_ ip: String, _ port: UInt16) throws -> sockaddr_in {
        var address = sockaddr_in()
        address.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        address.sin_family = sa_family_t(AF_INET)
        address.sin_port = port.bigEndian
        guard inet_pton(AF_INET, ip, &address.sin_addr) == 1 else {
            throw TailingError.protocolFailure("IPv4 地址无效：\(ip)")
        }
        return address
    }
}
