# 张雪 500RR 仪表接入（实验性）

本轮在 CarWithin v1.0.5 源码里新增了张雪 500RR 的仪表输出通道。**必须说明：真实握手报文尚未抓到，这一版是“按公开参数搭起来的实验性接入”**，实机能否出画需要在车上验证，并可能按抓包结果调整。

## 已知的公开参数

| 项 | 值 | 来源 |
|---|---|---|
| 仪表热点地址 | 192.168.43.1（iPhone 加入仪表热点后同网段 .1） | 公开说明 |
| 视频通道 | TCP 1111 | 公开说明 |
| 消息通道 | TCP 11113 | 公开说明 |
| 画面 | 由仪表返回参数后，手机发送 H.264 | 公开说明 |
| 分辨率 | 未公开，默认 800×480，可切 1280×720 | 推断（5 寸 TFT 常见值） |

官方仓库（xmz28/CarWithin）没有该仪表实现，issue #60 只有提问、没有回复，所以没有可参照的协议代码。

## 新增/改动的文件

| 文件 | 改动 |
|---|---|
| `App/Zx500rrOutput.swift` | **新增**。`Zx500rrProfile`（规格）、`Zx500rrConnection`（1111/11113 连接、首包解析、消息通道记录）、`Zx500rrOutput`（H.264 解码→缩放→重编码→按帧率写出）、`ZxSocket`（可读“任意长度”的非阻塞 TCP 客户端） |
| `App/ReceiverConfiguration.swift` | 新增 `zx500rrAddress`、`zx500rrProfile` 及 IPv4 校验（留空则自动取本网段 .1） |
| `App/NativeReceiver.swift` | 新增输出实例、启动/停止、CarPlay 帧分发、状态回调 `onZx500rrState` |
| `App/ReceiverViewController.swift` | 输出菜单新增「张雪 500RR 5 寸」；连接卡片；设置页（仪表 IP、画面规格）；画面页信息；默认值读写；状态刷新 |
| `TDSCarKit.xcodeproj/project.pbxproj` | 登记 `App/Zx500rrOutput.swift`（fileRef + buildFile + group + Sources） |

枚举 `HeadUnitOutput` 的新 case 追加在**末尾**，不影响已保存的输出方式 rawValue（`headUnitOutputV2`）。

## 实机使用步骤

1. iPhone 加入 500RR 仪表热点（SSID 以车机为准），确认手机 IP 落在 192.168.43.x。
2. CarWithin 首页把输出方式切到「张雪 500RR 5 寸」。
3. 进入「连接设置 → 仪表 IP 地址」：留空表示自动取同网段 .1（即 192.168.43.1）；也可直接填 192.168.43.1。
4. 「仪表画面」选择 800×480 或 1280×720（不确定就先用 800×480）。
5. 在仪表上打开投屏/导航投屏，再回 CarWithin 启动 CarPlay。
6. 观察首页卡片状态与「诊断与实验 → 日志」。

## 实机排障：先看日志

输出层会主动打印三类关键信息，用于补协议：

- `已连接视频通道 192.168.43.1:1111`
- `视频通道首包 N 字节：XX XX …｜{...}` —— 若仪表下发 JSON/二进制参数，会在这里显示
- `消息通道收到 N 字节：…` —— 11113 上的全部报文
- `首帧已发送（N 字节 Annex-B）` —— 证明手机确实在往仪表推 H.264

判断思路：

| 现象 | 含义 | 下一步 |
|---|---|---|
| 连 1111 就超时/拒绝 | 端口或角色不对（可能仪表当客户端连手机，而不是手机连仪表） | 抓包确认握手方向与端口，再改 `Zx500rrConnection.start()` |
| 连上但 2 秒无首包、推流后仪表无画面 | 缺少握手/请求报文，仪表不认裸 H.264 | 抓包补 `start()` 的握手发送与 `send()` 的封装 |
| 有画面但花屏/尺寸不对 | 规格不对 | 切另一档规格，或按首包里的参数让代码自动采用（已实现 JSON/小端 16 位两种解析） |
| 连上 1111、11113 失败 | 消息通道非必需或端口变体 | 视频通道仍会继续，不影响判断 |

## 抓包建议

手机侧抓自己发出的流量不方便，推荐：

1. 用一台笔记本开热点，让仪表和 iPhone 都接这个热点（或仪表热点 + 笔记本加入），在笔记本上 `tcpdump -i any -A 'tcp port 1111 or tcp port 11113'` 抓包；
2. 或者用支持端口镜像/抓包的路由器；
3. 拿到 pcap 后按“连接 → 仪表下发 → 手机请求 → 视频首帧”的顺序读，把报文字节贴进 issue，再补 `Zx500rrConnection`。

## 编译与验证

- 本机是 Windows，没有 Swift/Xcode 工具链，**未能编译验证**；代码按项目现有 `CfmotoOutput` / `CfmotoOutput.Session` 的同构写法实现，已做过符号、分支覆盖与括号平衡的静态检查。
- 在 macOS 上用 Xcode 打开 `TDSCarKit.xcodeproj` 编译即可；若工程文件异常，可运行 `python3 Tools/generate_project.py` 重新生成（脚本会扫描 `App/*.swift`）。
- 需要真机（iPhone）与仪表在同一网络下验证。

## 后续可以继续做的

- 抓到 pcap 后补握手与帧封装（这是唯一能让它真正出画的一步）。
- 若仪表实际是“仪表主动连手机”，把 `Zx500rrConnection` 改成监听模式（`ZxSocket` 已有可复用的 poll 循环，只需补 `listen/accept`）。
- 把 11113 的消息按类型解析（心跳/请求/参数），用消息驱动发送节奏，替代当前固定帧率发送。

## 安装到手机（全能签 / 侧载）

源码不能直接装，必须先生成 IPA。两条路：

### 路 1：云端 macOS 编译（没有 Mac 时用）

1. 把整个源码目录推到 GitHub（**不要提交 `App/BundledIdentity/` 里的证书**，`.gitignore` 已排除 `*.p7b/*.cer/*.x963`）。
2. 仓库 Actions 页手动运行 `Build unsigned IPA`（`.github/workflows/build-unsigned-ipa.yml`）。
   工作流会：下载官方 1.0.5 IPA → 提取三个认证文件到 `App/BundledIdentity/` → 运行 `Tools/generate_project.py` → `xcodebuild` 出未签名包 → 打包成 `CarWithin-1.0.5-zx500rr-unsigned.ipa`。
3. 下载 artifact 里的 IPA，用手机上的「全能签」导入并签名安装。
4. 首次启动若被拦：设置 → 通用 → VPN与设备管理 信任证书；iOS 16+ 还需开启开发者模式。

### 路 2：有 Mac 本地编译

```sh
./Tools/stage_identity.sh          # 从官方 IPA 提取认证文件（Windows 用 Tools/stage_identity.ps1）
python3 Tools/generate_project.py
xcodebuild -project TDSCarKit.xcodeproj -scheme TDSCarKit -configuration Release \
  -sdk iphoneos CODE_SIGNING_ALLOWED=NO -derivedDataPath build/source
# 再把 build/source/Build/Products/Release-iphoneos/TDSCarKit.app 打成 Payload/*.ipa
```

或直接在 Xcode 里选自己的 Team 签名、连 iPhone 运行。

### 认证文件为什么必须有

`certificate.p7b` / `leaf.cer` / `private.x963` 是配件认证身份，官方说明允许从安装包提取。没有它们：App 能装、能打开、能出界面，但**本机 CarPlay 会话建立不起来，仪表也就收不到画面**。

### 已知风险

- 签名证书：免费 Apple ID 7 天失效；「全能签」类共享企业证书可能随时被吊销（掉签），掉签后需重新签名。
- 本版协议未验证：装好后若仪表黑屏，先看 App 内「诊断与实验 → 日志」。