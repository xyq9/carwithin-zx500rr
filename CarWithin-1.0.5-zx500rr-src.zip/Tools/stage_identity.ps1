# 从官方 CarWithin 1.0.5 未签名 IPA 中提取 CarPlay 认证文件到 App/BundledIdentity/。
# 这些文件被 .gitignore 排除，不要提交到公开仓库；仅供本机编译使用。
param(
    [string]$Ipa = "D:\桌面\CarWithin-1.0.5-official.ipa"
)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent (Split-Path -Parent $PSCommandPath)
if (-not (Test-Path -LiteralPath $Ipa)) {
    $Ipa = Join-Path $env:TEMP 'CarWithin-1.0.5-unsigned.ipa'
    if (-not (Test-Path -LiteralPath $Ipa)) {
        curl.exe -L --fail -o $Ipa "https://github.com/xmz28/CarWithin/releases/download/v1.0.5/CarWithin-1.0.5-unsigned.ipa"
    }
}
$work = Join-Path $env:TEMP ('cw_ident_' + [guid]::NewGuid().ToString('N'))
$copy = Join-Path $env:TEMP ('cw_ident_' + [guid]::NewGuid().ToString('N') + '.zip')
Copy-Item -LiteralPath $Ipa -Destination $copy -Force
Expand-Archive -LiteralPath $copy -DestinationPath $work -Force
$app = Join-Path $work 'Payload\TDSCarKit.app'
$dest = Join-Path $root 'App\BundledIdentity'
New-Item -ItemType Directory -Force -Path $dest | Out-Null
foreach ($name in 'certificate.p7b', 'leaf.cer', 'private.x963') {
    Copy-Item -LiteralPath (Join-Path $app $name) -Destination (Join-Path $dest $name) -Force
}
Remove-Item -LiteralPath $work -Recurse -Force
Remove-Item -LiteralPath $copy -Force
Get-ChildItem $dest | Select-Object Name, Length | Format-Table -AutoSize
"已暂存认证文件；在 macOS 上运行 python3 Tools/generate_project.py 后会打包进 App。"
