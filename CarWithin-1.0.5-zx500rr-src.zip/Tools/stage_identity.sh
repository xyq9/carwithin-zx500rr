#!/bin/bash
# 从官方 CarWithin 1.0.5 未签名 IPA 中提取 CarPlay 认证文件，暂存到 App/BundledIdentity/。
# 这些文件被 .gitignore 排除，不要提交到公开仓库；仅供本机编译使用。
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
ipa="${1:-}"
if [[ -z "$ipa" ]]; then
  ipa="/tmp/CarWithin-1.0.5-unsigned.ipa"
  [[ -f "$ipa" ]] || curl -L --fail -o "$ipa" \
    "https://github.com/xmz28/CarWithin/releases/download/v1.0.5/CarWithin-1.0.5-unsigned.ipa"
fi
[[ -f "$ipa" ]] || { echo "找不到 IPA：$ipa"; exit 1; }
work="$(mktemp -d)"
unzip -q "$ipa" -d "$work"
app="$work/Payload/TDSCarKit.app"
mkdir -p "$root/App/BundledIdentity"
cp "$app/certificate.p7b" "$app/leaf.cer" "$app/private.x963" "$root/App/BundledIdentity/"
rm -rf "$work"
ls -l "$root/App/BundledIdentity"
echo "已暂存认证文件，重新运行 python3 Tools/generate_project.py 后会打包进 App。"
